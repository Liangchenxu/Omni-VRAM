"""
Omni-VRAM Core: Zero-Copy CUDA Audio-to-LLM Bridge
====================================================

High-performance audio processing and LLM inference bridge with
zero-copy VRAM memory injection.

Modules:
    - audio_utils: Audio format detection, loading, conversion
    - whisper_bridge: Whisper model backend integration (faster-whisper / whisper.cpp / OpenAI API)
    - stream_processor: Real-time audio stream processing with VAD
    - streaming_asr: Real-time streaming speech recognition with sliding window
    - api_server: FastAPI-based REST + WebSocket transcription API
"""

__version__ = "1.0.0"

# CUDA extension (built from vram_hacker.cu)
try:
    import vram_core._vram_hacker as _backend
    CUDA_AVAILABLE = True
    # Expose CUDA functions if available
    stress_test = _backend.stress_test
    launch_dynamic_kernel = _backend.launch_dynamic_kernel
    inject_into_model = _backend.inject_into_model
    query_memory = _backend.query_memory
except (ImportError, AttributeError):
    CUDA_AVAILABLE = False

from vram_core.audio_utils import AudioProcessor
from vram_core.whisper_bridge import (
    WhisperBridge, WhisperBackend, WhisperResult,
    TranscriptionResult, AudioPreprocessor,
)
from vram_core.stream_processor import StreamProcessor, StreamConfig, StreamState
from vram_core.streaming_asr import StreamASR, StreamASRConfig, StreamASRResult
from vram_core.noise_reduction import NoiseReducer
from vram_core.emotion_recognition import EmotionRecognizer
from vram_core.speaker_diarization import SpeakerDiarizer
from vram_core.config import config, OmniConfig, setup_logging

__all__ = [
    # Core
    "AudioProcessor",
    "WhisperBridge",
    "WhisperBackend",
    "WhisperResult",
    "TranscriptionResult",
    "AudioPreprocessor",
    "StreamProcessor",
    "StreamConfig",
    "StreamState",
    # Streaming ASR
    "StreamASR",
    "StreamASRConfig",
    "StreamASRResult",
    # New Modules
    "NoiseReducer",
    "EmotionRecognizer",
    "SpeakerDiarizer",
    # Configuration
    "config",
    "OmniConfig",
    "setup_logging",
    "CUDA_AVAILABLE",
]